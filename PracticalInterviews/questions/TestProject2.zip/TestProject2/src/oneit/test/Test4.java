package oneit.test;

import java.util.Calendar;

/**
 *
 * @author OneIT
 */
public class Test4
{
    public static void main(String[] args) 
    {
//      We have to create an application for hotel booking. Hotel is having 3 number of rooms.
//      Write down a code for checkAvailability function to check if 'y' number of rooms are
//      available on so and so date for start time and end time.
//      If room is partially available then don't consider that as available.
        
//      Example. Room 1 is already booked for 6th Nov,2014 from 12PM to 6PM.Consider this as
//              available for 6PM to 9PM but consider unavailable if we check for 5PM to 9PM.
        
//      Use ReadRegister.readAllBookings() to fetch all current bookings.
    }
    
    public static boolean checkAvailability(int noOfRooms, Calendar start, Calendar end)
    {
        return true;
    }
}
