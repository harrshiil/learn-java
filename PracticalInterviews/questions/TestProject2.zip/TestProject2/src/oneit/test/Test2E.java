package oneit.test;

/**
 *
 * @author OneIT
 */
public class Test2E
{
    public static void main (String[] args)
    {
//      Use ReadDatabase.getEmployees () to get all employees
//      Print out the organisation hierarchy, with each level indented 4 spaces e.g. + their salary and the salary of all subordinates 
//      e.g. 80 is the sum of Tom Jones + Mark Smith + Phil Jones + David Jones + Paul Phillips salary
        
//      Tom Jones               80
//          Mark Smith          40
//              Phil Jones      10
//              David Jones     10
//          Paul Phillips       15
//      Another Manager
//          Subordinate
//          Subordinate 2

    }
}
