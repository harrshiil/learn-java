package oneit.test;

/**
 *
 * @author OneIT
 */
public class Test3
{
    public static void main(String[] args) 
    {
//      We are having a class named MyDoublyList with some methods like addFirst,addLast etc.
//      Add a method in that class named addNewNode(E element). This method will check if element is
//      already present in our list. If this element is not present then add this element at the last.
//      If its already present then add this new element after that existing element.
//      Also add another element named 'X' between these duplicate elements to differentiate them.
        
//      Example.
//              suppose we are having list like:: O    N   E   I
//              Now If I want to add 'T' in this list then output list should be like::
//                  O   N   E   I   T
//              Now If I want to add 'E' in this list then output list should be like::
//                  O   N   E   X   E   I   T
        
        
        MyDoublyList<String> dl = new MyDoublyList<String>();
        
        dl.addFirst("E");
        dl.addFirst("N");
        dl.addLast("I");
        dl.addFirst("O");
        dl.addLast("T");
        dl.iterateForward();
    }

    
}
