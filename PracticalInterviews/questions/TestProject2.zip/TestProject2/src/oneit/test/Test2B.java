package oneit.test;

/**
 *
 * @author OneIT
 */
public class Test2B
{
    public static void main (String[] args)
    {
//      Take output of Test4 to print all employees and their salary.
//      It should print records in sorted order of Employee Last Name, Frist Name, and City.
        
//      Example Output::
//      David Barton Perth 200.00
//      Harsh Shah Navarsi  600.00
        
    }
}
