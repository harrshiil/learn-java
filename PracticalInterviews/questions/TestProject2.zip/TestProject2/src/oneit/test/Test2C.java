package oneit.test;

/**
 *
 * @author OneIT
 */
public class Test2C
{
    public static void main (String[] args)
    {
//      Use ReadDatabase.getEmployees () to get all employees
//      Print out those employees who are managers
    }
}
