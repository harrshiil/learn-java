package oneit.test;

/**
 *
 * @author OneIT
 */
public class Test2A
{
    public static void main (String[] args)
    {
//      Use ReadDatabase.getPayRecords() to get all salary records.
//      It will have Employee wise salary. 
//      Print out the total salary earned by each employee        
    }
}
