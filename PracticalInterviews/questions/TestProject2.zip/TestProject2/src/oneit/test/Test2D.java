package oneit.test;

/**
 *
 * @author OneIT
 */
public class Test2D
{
    public static void main (String[] args)
    {
//      Use ReadDatabase.getEmployees () to get all employees
//      Print out the organisation hierarchy, with each level indented 4 spaces e.g.
//      Tom Jones
//          Mark Smith
//              Phil Jones
//              David Jones
//          Paul Phillips
//      Another Manager
//          Subordinate
//          Subordinate 2

    }
}
