/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package oneit.model;

import java.util.Calendar;

/**
 *
 * @author OneIT
 */
public class Booking
{
    private int roomNo;
    private Calendar start;
    private Calendar end;

    public int getRoomNo() {
        return roomNo;
    }

    public void setRoomNo(int roomNo) {
        this.roomNo = roomNo;
    }

    public Calendar getStart() {
        return start;
    }

    public void setStart(Calendar start) {
        this.start = start;
    }

    public Calendar getEnd() {
        return end;
    }

    public void setEnd(Calendar end) {
        this.end = end;
    }

    public Booking(int roomNo, Calendar start, Calendar end) {
        this.roomNo = roomNo;
        this.start = start;
        this.end = end;
    }
    
}
