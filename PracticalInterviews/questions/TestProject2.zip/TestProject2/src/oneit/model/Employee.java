/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package oneit.model;

/**
 *
 * @author OneIT
 */
public class Employee
{
    private String firstName;
    private String lastName;
    private String city;
    private Employee manager;

    
    public Employee(String firstName, String lastName, String city, Employee manager)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.city = city;
        this.manager = manager;
    }
    
    

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Employee getManager()
    {
        return manager;
    }
}
