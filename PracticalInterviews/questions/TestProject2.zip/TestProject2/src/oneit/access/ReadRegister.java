/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package oneit.access;

import java.util.ArrayList;
import java.util.GregorianCalendar;
import oneit.model.Booking;

/**
 *
 * @author OneIT
 */
public class ReadRegister
{
    public static ArrayList<Booking> readAllBookings()
    {
        ArrayList<Booking> result = new ArrayList<Booking>();
        
        result.add(new Booking(1, new GregorianCalendar(2014, 11, 06, 12, 00, 00), new GregorianCalendar(2014, 11, 06, 18, 00, 00)));
        result.add(new Booking(1, new GregorianCalendar(2014, 11, 07, 12, 00, 00), new GregorianCalendar(2014, 11, 06, 18, 00, 00)));
        result.add(new Booking(3, new GregorianCalendar(2014, 11, 06, 12, 00, 00), new GregorianCalendar(2014, 11, 06, 18, 00, 00)));
        
        result.add(new Booking(2, new GregorianCalendar(2014, 11, 06, 12, 00, 00), new GregorianCalendar(2014, 11, 06, 18, 00, 00)));
        
        return result;
    }
}
