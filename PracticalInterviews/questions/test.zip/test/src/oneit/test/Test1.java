package oneit.test;

import oneit.access.*;
import oneit.model.*;

/**
 *
 * @author david
 */
public class Test1
{
    public static void main (String[] args)
    {
        // Print it out the total value of all inventory combined 
        // Use ReadInventory.getInventory() to get the inventory
    }
}
