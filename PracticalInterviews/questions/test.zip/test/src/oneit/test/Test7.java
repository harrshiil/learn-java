package oneit.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.logging.Level;
import java.util.logging.Logger;
import oneit.model.Line;

/**
 *
 * @author david
 */
public class Test7
{
    public static void main (String[] args)
    {        
        // Write a process that reads the bytes input on stdin and writes each byte out UNLESS the next byte or preceeding byte are identical
        // For example (assuming the bytes are characters) 12334566676 would write out 124576.  The 3 & 6 are ommitted because the are duplicated.
        // Tests:
        // abaa = ab
        // abba = aa
        // aabbcc = <empty string>
        // abbcdde = abe
    }
    
    

}
