package oneit.test;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import oneit.access.ReadInventory;
import oneit.model.*;

/**
 *
 * @author david
 */
public class Test4
{
    public static void main (String[] args)
    {
        // Print out the records, grouped by location, with totals and sub totals e.g.
        // Perth
        //      Knife        20     300
        //      Cup          10     100
        //                   30     400
        // Melbourne
        //    etc.
        // No formatting is required.
        //
        // Use ReadInventory.getInventory() to get the inventory.  The system must be able to cope with new products / locations.
    }
}
