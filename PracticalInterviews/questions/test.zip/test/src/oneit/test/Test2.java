package oneit.test;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import oneit.access.*;
import oneit.model.*;

/**
 *
 * @author david
 */
public class Test2 {

    public static void main(String[] args) 
    {
        // Print out the quantity in stock and total value of that stock grouped by product (across all locations) e.g.
        // Knife        20     300
        // Cup          10     100
        // Use ReadInventory.getInventory() to get the inventory.  The system must be able to cope with new products.
        

    }
}
