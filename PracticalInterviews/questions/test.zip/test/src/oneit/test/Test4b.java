package oneit.test;

import java.text.DecimalFormat;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import oneit.access.*;
import oneit.model.*;

/**
 *
 * @author david
 */
public class Test4b
{
    public static void main (String[] args)
    {
        // Print out the records, grouped by location, with totals and sub totals e.g.
        // Perth
        //      Knife        20     $300
        //      Cup          10     $100
        //      Plate     1,000   $1,000
        // -----------------------------
        //                1,430   $1,400
        // -----------------------------
        //
        // Melbourne
        //    etc.
        // Formatting is important.  It is important that the right of the numbers align and that numbers are represented with , and $ where appropriate
        
    }
}
