/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package oneit.model;

import java.util.Objects;

/**
 *
 * @author david
 */
public class Product
{
    public String   productCode;
    public String   description;
    public double   costPrice;

    public Product(String productCode, String description, double costPrice)
    {
        this.productCode = productCode;
        this.description = description;
        this.costPrice = costPrice;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Product)) return false;
        Product product = (Product) o;
        return Double.compare(product.costPrice, costPrice) == 0 &&
                productCode.equals(product.productCode) &&
                description.equals(product.description);
    }

    @Override
    public int hashCode() {
        return Objects.hash(productCode, description, costPrice);
    }

    @Override
    public String toString()
    {
        return productCode;
    }
    
    
}
