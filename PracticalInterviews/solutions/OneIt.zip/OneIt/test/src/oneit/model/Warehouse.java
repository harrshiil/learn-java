/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package oneit.model;

import java.util.Objects;

/**
 *
 * @author david
 */
public class Warehouse
{
    public String warehouseCode;

    public Warehouse(String warehouseCode)
    {
        this.warehouseCode = warehouseCode;
    }

    @Override
    public String toString()
    {
        return warehouseCode;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Warehouse)) return false;
        Warehouse warehouse = (Warehouse) o;
        return warehouseCode.equals(warehouse.warehouseCode);
    }

    @Override
    public int hashCode() {
        return Objects.hash(warehouseCode);
    }
}
