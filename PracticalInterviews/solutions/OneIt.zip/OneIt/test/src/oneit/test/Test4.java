package oneit.test;

import oneit.access.ReadInventory;
import oneit.model.Inventory;
import oneit.model.Product;
import oneit.model.Warehouse;

import java.util.HashMap;
import java.util.Map;

/**
 * @author david
 */
public class Test4 {
    public static void main(String[] args) {
        // Print out the records, grouped by location, with totals and sub totals e.g.
        // Perth
        //      Knife        20     300
        //      Cup          10     100
        //                   30     400
        // Melbourne
        //    etc.
        // No formatting is required.
        //
        // Use ReadInventory.getInventory() to get the inventory.  The system must be able to cope with new products / locations.

        Map<Warehouse, Map<Product, Integer>> productsByLocation = new HashMap<>();

        for (Inventory inventory : ReadInventory.getInventory()) {
            Warehouse location = inventory.location;
            Product product = inventory.productInStock;
            if (productsByLocation.containsKey(location)) {
                Map<Product, Integer> productList = productsByLocation.get(location);
                if (productList.containsKey(product)) {
                    int newQuantity = productList.get(product) + inventory.quantityInStock;
                    productList.put(product, newQuantity);
                } else {
                    productList.put(product, inventory.quantityInStock);
                }
            } else {
                Map<Product, Integer> productList = new HashMap<>();
                productList.put(inventory.productInStock, inventory.quantityInStock);
                productsByLocation.put(location, productList);
            }
        }

        for (Map.Entry<Warehouse, Map<Product, Integer>> warehouseMapEntry : productsByLocation.entrySet()) {
            Warehouse location = warehouseMapEntry.getKey();
            Map<Product, Integer> productIntegerMap = warehouseMapEntry.getValue();

            System.out.println(location.warehouseCode);

            for (Map.Entry<Product, Integer> productIntegerEntry : productIntegerMap.entrySet()) {
                Product product = productIntegerEntry.getKey();
                int totalQuantity = productIntegerEntry.getValue();

                System.out.println("\t" + product.description + "\t" + totalQuantity + "\t" + product.costPrice * totalQuantity);
            }
        }
    }
}
