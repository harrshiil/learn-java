package oneit.test;

import oneit.access.ReadLines;
import oneit.model.Line;

import java.util.Comparator;
import java.util.List;

/**
 * @author david
 */
public class Test6 {
    public static void main(String[] args) {
        // A oneit.model.Line is an interval between two points. Each point is represented by an integer.
        // Get the lines using ReadLines.getLines (args.length > 0 ? args[0] : "")
        //
        // Summarise the lines into the minimal set of lines that can represent the points.
        // Lines can be combined if their points overlap.
        // For example, the line from points 1 - 20 and the line from points 15 - 25 overlap and can be combined into 1 - 25.
        // The line 1 - 20 and 20 - 25 DO overlap, 
        // The line 1 - 20 an 21 - 25  DO NOT overlap, 
        // e.g. 1 - 20, 15 - 25, and 40 - 50 can be represented as 1 - 25 and 40 - 50.
        //
        // Print out the lines after they have been summarised.

        List<Line> lines = ReadLines.getLines("test");
        lines.sort((Comparator) (o1, o2) -> {

            int firstPointNo1 = ((Line) o1).firstPointNo;
            int firstPointNo2 = ((Line) o2).firstPointNo;
            return Integer.compare(firstPointNo1, firstPointNo2);
        });

        for (int i = 0; i < lines.size(); i++) {
            if (lines.size() > i + 1 && lines.get(i).lastPointNo > lines.get(i + 1).firstPointNo) {
                lines.get(i).lastPointNo = lines.get(i + 1).lastPointNo;
                lines.remove(i + 1);
            }
        }

        for (Line line : lines) {
            System.out.println(line.firstPointNo + "\t" + line.lastPointNo);
        }

    }
}
