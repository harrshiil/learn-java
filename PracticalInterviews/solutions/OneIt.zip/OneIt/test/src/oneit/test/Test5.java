package oneit.test;

import oneit.access.ReadLines;
import oneit.model.Inventory;
import oneit.model.Line;

import java.util.Comparator;
import java.util.List;

/**
 * @author david
 */
public class Test5 {
    public static void main(String[] args) {
        // A oneit.model.Line is an interval between two points. Each point is represented by an integer.
        // Sort the Spatial oneit.model.Line objects by the first point number (refer to PrintLines.java).  Same as:
        // ORDER BY firstPointNo
        //
        // Get the lines using ReadLines.getLines (args.length > 0 ? args[0] : "")

        List<Line> lines = ReadLines.getLines(args.length > 0 ? args[0] : "");

        lines.sort((Comparator) (o1, o2) -> {

            int firstPointNo1 = ((Line) o1).firstPointNo;
            int firstPointNo2 = ((Line) o2).firstPointNo;
            return Integer.compare(firstPointNo1, firstPointNo2);
        });

        for (Line line : lines) {
            System.out.println(line.firstPointNo + "\t" + line.lastPointNo);
        }
    }
}
