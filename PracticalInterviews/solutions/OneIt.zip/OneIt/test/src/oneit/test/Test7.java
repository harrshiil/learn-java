package oneit.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

/**
 * @author david
 */
public class Test7 {
    public static void main(String[] args) {
        // Write a process that reads the bytes input on stdin and writes each byte out UNLESS the next byte or preceeding byte are identical
        // For example (assuming the bytes are characters) 12334566676 would write out 124576.  The 3 & 6 are ommitted because the are duplicated.
        // Tests:
        // abaa = ab
        // abba = aa
        // aabbcc = <empty string>
        // abbcdde = abe

        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        String input = "";
        try {
            input = br.readLine();
        } catch (IOException e) {
            e.printStackTrace();
        }

        char[] chars = input.toCharArray();
        StringBuilder resultString = new StringBuilder();

        for (int i = 0; i < chars.length; i++) {
            if (chars.length > i + 1 && chars[i] != chars[i + 1]) {
                resultString.append(chars[i]);
            } else if (chars.length == i + 1) {
                resultString.append(chars[i]);
            } else {
                i = i + 1;
            }
        }
        System.out.println(resultString);
    }
}
