package oneit.test;

import oneit.access.ReadInventory;
import oneit.model.Inventory;
import oneit.model.Product;
import oneit.model.Warehouse;

import java.text.NumberFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * @author david
 */
public class Test4b {
    public static void main(String[] args) {
        // Print out the records, grouped by location, with totals and sub totals e.g.
        // Perth
        //      Knife        20     $300
        //      Cup          10     $100
        //      Plate     1,000   $1,000
        // -----------------------------
        //                1,430   $1,400
        // -----------------------------
        //
        // Melbourne
        //    etc.
        // Formatting is important.  It is important that the right of the numbers align and that numbers are represented with , and $ where appropriate


        Map<Warehouse, Map<Product, Integer>> productsByLocation = new HashMap<>();

        for (Inventory inventory : ReadInventory.getInventory()) {
            Warehouse location = inventory.location;
            Product product = inventory.productInStock;
            if (productsByLocation.containsKey(location)) {
                Map<Product, Integer> productList = productsByLocation.get(location);
                if (productList.containsKey(product)) {
                    int newQuantity = productList.get(product) + inventory.quantityInStock;
                    productList.put(product, newQuantity);
                } else {
                    productList.put(product, inventory.quantityInStock);
                }
            } else {
                Map<Product, Integer> productList = new HashMap<>();
                productList.put(inventory.productInStock, inventory.quantityInStock);
                productsByLocation.put(location, productList);
            }
        }

        for (Map.Entry<Warehouse, Map<Product, Integer>> warehouseMapEntry : productsByLocation.entrySet()) {
            Warehouse location = warehouseMapEntry.getKey();
            Map<Product, Integer> productIntegerMap = warehouseMapEntry.getValue();

            int totalItems = 0;
            double totalCost = 0;

            System.out.println(location.warehouseCode);

            for (Map.Entry<Product, Integer> productIntegerEntry : productIntegerMap.entrySet()) {
                Product product = productIntegerEntry.getKey();
                int totalQuantity = productIntegerEntry.getValue();

                totalItems = totalItems + totalQuantity;
                totalCost = totalCost + product.costPrice * totalQuantity;

                System.out.println("\t" + product.description + "\t" + totalQuantity + "\t" + formatCurrency(product.costPrice * totalQuantity));
            }
            System.out.println("----------------------");
            System.out.println("\t\t\t" + totalItems + "\t" + formatCurrency(totalCost));
            System.out.println("----------------------");
        }
    }

    private static String formatCurrency(double value) {
        return NumberFormat.getCurrencyInstance().format(value);
    }
}
