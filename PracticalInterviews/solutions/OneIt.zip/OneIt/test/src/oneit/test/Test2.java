package oneit.test;

import oneit.access.ReadInventory;
import oneit.model.Inventory;
import oneit.model.Product;

import java.util.HashMap;
import java.util.Map;

/**
 * @author david
 */
public class Test2 {

    public static void main(String[] args) {
        // Print out the quantity in stock and total value of that stock grouped by product (across all locations) e.g.
        // Knife        20     300
        // Cup          10     100
        // Use ReadInventory.getInventory() to get the inventory.  The system must be able to cope with new products.

        Map<Product, Integer> productList = new HashMap<>();

        for (Inventory inventory : ReadInventory.getInventory())
        {
            Product product = inventory.productInStock;
            if (productList.containsKey(product)) {
                int newQuantity = productList.get(product) +  inventory.quantityInStock;
                productList.put(product, newQuantity);
            } else {
                productList.put(product, inventory.quantityInStock);
            }
        }

        for (Map.Entry<Product, Integer> productIntegerEntry : productList.entrySet()) {
            Product product = productIntegerEntry.getKey();
            int totalQuantity = productIntegerEntry.getValue();

            System.out.println(product.description + "\t" + totalQuantity + "\t" + product.costPrice * totalQuantity);
        }

    }
}
