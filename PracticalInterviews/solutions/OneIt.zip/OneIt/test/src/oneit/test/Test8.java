package oneit.test;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * @author david
 */
public class Test8 {
    public static void main(String[] args) {
        // Take the process from Test7
        // Assume that our out has very high latency (perhaps it is pushing over a satellite).
        // We want to continue reading from stdin and buffer it while the writing is blocked.
        // Assume I want a solution using blocking IO and a reader / writer thread, not NIO
        //
        // Use one thread to read the bytes in.
        // Use another thread to write the bytes out.
        // Use a threadsafe buffer of some form between them.
        List<String> stringList = new ArrayList<>();
//        ExecutorService executor = Executors.newFixedThreadPool(2);
//        executor.awaitTermination()
        List<String> finalStringList = Collections.synchronizedList(stringList);
        new Thread(() -> {
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
            try {
                finalStringList.add(br.readLine());
            } catch (IOException e) {
                e.printStackTrace();
            }
        }).start();

        new Thread(() -> {
            if (!finalStringList.isEmpty()) {
                char[] chars = finalStringList.get(0).toCharArray();
                StringBuilder resultString = new StringBuilder();

                for (int i = 0; i < chars.length; i++) {
                    if (chars.length > i + 1 && chars[i] != chars[i + 1]) {
                        resultString.append(chars[i]);
                    } else if (chars.length == i + 1) {
                        resultString.append(chars[i]);
                    } else {
                        i = i + 1;
                    }
                }
                System.out.println(resultString);
            }
        }).start();
    }
}
