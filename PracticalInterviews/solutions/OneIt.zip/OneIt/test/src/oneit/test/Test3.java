package oneit.test;

import oneit.access.ReadInventory;
import oneit.model.Inventory;
import oneit.model.Product;

import java.util.Comparator;
import java.util.List;

/**
 * @author david
 */
public class Test3 {
    public static void main(String[] args) {
        // Sort the inventory records by location as the primary sort and then product as the second sort and print them out
        // In SQL, this is equivalent to:
        // ORDER BY productCode, warehouseCode
        //
        // Use ReadInventory.getInventory() to get the inventory.  The system must be able to cope with new products / locations.

        List<Inventory> newList = ReadInventory.getInventory();

        newList.sort((Comparator) (o1, o2) -> {

            String locationCode1 = ((Inventory) o1).location.warehouseCode;
            String locationCode2 = ((Inventory) o2).location.warehouseCode;
            int sLocation = locationCode1.compareTo(locationCode2);

            if (sLocation != 0) {
                return sLocation;
            }

            String prodcutCode1 = ((Inventory) o1).productInStock.productCode;
            String prodcutCode2 = ((Inventory) o2).productInStock.productCode;
            return prodcutCode1.compareTo(prodcutCode2);
        });

        for (Inventory invRecord : newList) {
            Product product = invRecord.productInStock;

            System.out.println("Location:" + invRecord.rack + "@" + invRecord.location.warehouseCode + "\tProduct:" + product.productCode + "\tQty:" + invRecord.quantityInStock + "\tCost:" + invRecord.quantityInStock * product.costPrice);
        }
    }
}
