/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package oneit.model;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;

/**
 * @author OneIT
 */
public class Employee implements Comparable<Employee> {
    private String firstName;
    private String lastName;
    private String city;
    private Employee manager;
    private List<Employee> subEmployeeList = new ArrayList<>();
    private double totalSalaryOfSubordinates;


    public Employee(String firstName, String lastName, String city, Employee manager) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.city = city;
        this.manager = manager;
    }

    public Employee() {
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public Employee getManager() {
        return manager;
    }

    public List<Employee> getSubEmployeeList() {
        return subEmployeeList;
    }

    public void setSubEmployeeList(List<Employee> subEmployeeList) {
        this.subEmployeeList = subEmployeeList;
    }

    public double getTotalSalaryOfSubordinates() {
        return totalSalaryOfSubordinates;
    }

    public void setTotalSalaryOfSubordinates(double totalSalaryOfSubordinates) {
        this.totalSalaryOfSubordinates = totalSalaryOfSubordinates;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Employee)) return false;
        Employee employee = (Employee) o;
        return getFirstName().equals(employee.getFirstName()) &&
                getLastName().equals(employee.getLastName()) &&
                getCity().equals(employee.getCity()) &&
                getManager().equals(employee.getManager());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getFirstName(), getLastName(), getCity(), getManager());
    }

    @Override
    public int compareTo(Employee o) {

        return Comparator.comparing(Employee::getLastName)
                .thenComparing(Employee::getFirstName)
                .thenComparing(Employee::getCity)
                .compare(this, o);

    }
}
