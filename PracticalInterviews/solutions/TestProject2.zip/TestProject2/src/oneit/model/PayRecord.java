package oneit.model;

/**
 *
 * @author david
 */
public class PayRecord
{
    private Employee    employee;
    
    private double      salary;

    public PayRecord(Employee employee, double salary)
    {
        this.employee = employee;
        this.salary = salary;
    }
    

    public Employee getEmployee()
    {
        return employee;
    }

    public double getSalary()
    {
        return salary;
    }
}
