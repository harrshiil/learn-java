/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package oneit.test;

/**
 * @author OneIT
 */
public class MyDoublyList<E> {
    private class Node {
        E element;
        Node next;
        Node prev;

        public Node(E element, Node next, Node prev) {
            this.element = element;
            this.next = next;
            this.prev = prev;
        }
    }

    private Node head;
    private Node tail;
    private int size;

    public MyDoublyList() {
        size = 0;
    }

    public void addFirst(E element) {
        Node tmp = new Node(element, head, null);

        if (head != null) {
            head.prev = tmp;
        }

        head = tmp;

        if (tail == null) {
            tail = tmp;
        }

        size++;
        System.out.println("adding: " + element);
    }

    public void addLast(E element) {
        Node tmp = new Node(element, null, tail);

        if (tail != null) {
            tail.next = tmp;
        }

        tail = tmp;

        if (head == null) {
            head = tmp;
        }
        size++;
        System.out.println("adding: " + element);
    }

    public void iterateForward() {
        System.out.println("iterating forward..");

        Node tmp = head;

        while (tmp != null) {
            System.out.println(tmp.element);
            tmp = tmp.next;
        }
    }

    public void iterateBackward() {
        System.out.println("iterating backword..");

        Node tmp = tail;

        while (tmp != null) {
            System.out.println(tmp.element);
            tmp = tmp.prev;
        }
    }

    public void addNewNode(E element) {
        Node current = head;
        boolean found = false;

        while (current != null) {
            if (current.element == element) {
                found = true;
                break;
            }
            current = current.next;
        }

        if (!found) {
            addLast(element);
        } else {
            insertAfter(current, element);
        }
    }

    public void insertAfter(Node previous, E element) {
        E xElement = (E) "X";
        Node next = previous.next;

        Node xNode = new Node(xElement, previous.next, previous);
        previous.next = xNode;
        if (next != null) next.prev = xNode;

        Node newNode = new Node(element, next, xNode);
        xNode.next = newNode;
        if (next != null) next.prev = newNode;
    }
}
