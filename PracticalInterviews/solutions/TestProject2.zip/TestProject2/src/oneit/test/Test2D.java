package oneit.test;

import oneit.access.ReadDatabase;
import oneit.model.Employee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author OneIT
 */
public class Test2D {
    static Employee mainManager = new Employee();
    static List<Employee> employees = new ArrayList<>();

    public static void main(String[] args) {
//      Use ReadDatabase.getEmployees () to get all employees
//      Print out the organisation hierarchy, with each level indented 4 spaces e.g.
//      Tom Jones
//          Mark Smith
//              Phil Jones
//              David Jones
//          Paul Phillips
//      Another Manager
//          Subordinate
//          Subordinate 2

        employees.addAll(Arrays.asList(ReadDatabase.getEmployees()));
        buildManagerTree(mainManager);
        printTree(mainManager, 0);
    }

    private static List<Employee> getEmployeesByManager(Employee manager) {
        List<Employee> employeeList = new ArrayList<>();
        for (Employee employee : employees) {
            if (employee.getManager() == null && manager.getFirstName() == null) {
                employeeList.add(employee);
                continue;
            }
            if (employee.getManager() != null && employee.getManager().equals(manager)) {
                employeeList.add(employee);
            }
        }
        return employeeList;
    }

    private static void buildManagerTree(Employee mainManager) {
        List<Employee> employeeList = getEmployeesByManager(mainManager);
        mainManager.setSubEmployeeList(employeeList);
        if (employeeList.isEmpty()) {
            return;
        }
        for (Employee employee : employeeList) {
            buildManagerTree(employee);
        }
    }

    private static void printTree(Employee mainManager, int level) {
        for (int i = 0; i < level; i++) {
            System.out.print("\t");
        }
        System.out.println(mainManager.getFirstName() != null ? mainManager.getFirstName() + " " + mainManager.getLastName() : "");

        List<Employee> employeeList = mainManager.getSubEmployeeList();

        for (Employee employee : employeeList) {
            printTree(employee, level + 1);
        }
    }
}
