package oneit.test;

/**
 *
 * @author OneIT
 */
public class Test5
{
    public static void main (String[] args)
    {
        generatePattern(5);
        System.out.println ();
        System.out.println ();
        generatePattern(7);
    }
    
    private static void generatePattern(int rows)
    {
//      Write Java Code to print pattern as below (formatting / indentation is not important)
//      It should print number of rows as per our input.
//      Suppose I am giving rows=5,then it should print 5 rows as mentioned below.
//        
//
//                      1               
//                  -1      -1
//               1      2       1
//          -1      -3     -3       -1
//      1       4       6       4       1
// 
//  The pattern is that each number is the sum of the two numbers above (left & right) * -1
//  For example, 4 = ( -1 + -1 ) * -1
        
    }
}
