/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package oneit.test;

import java.util.Arrays;

/**
 * Check if a char[] is a palindrome i.e. the same forward as backwards WITHOUT USING EXTERNAL LIBRARIES.
 * Test examples are getTestData1 (), getTestData2 (), getTestData3 (), getTestData4 ()
 * Test your function with the 4 examples and print the char array as a string and the result.
 */
public class Test1B
{
    
    public static void main(String...args)
    {
        char[] input1,input2,input3,input4;
        input1 = getTestData1();
        input2 = getTestData2();
        input3 = getTestData3();
        input4 = getTestData4();

        System.out.println(String.valueOf(input1) + " is palindrome? - " + isPalindrome(input1));
        System.out.println(String.valueOf(input2) + " is palindrome? - " + isPalindrome(input2));
        System.out.println(String.valueOf(input3) + " is palindrome? - " + isPalindrome(input3));
        System.out.println(String.valueOf(input4) + " is palindrome? - " + isPalindrome(input4));
        
    }

    // MODIFY ME!!!
    public static boolean isPalindrome (char[] input)
    {
        String result = "";
        for (int i = input.length - 1; i >= 0; i--) {
            result = result + input[i];
        }
        return Arrays.equals(input, result.toCharArray());
    }
    
    
    public static char[] getTestData1 ()
    {
        return "abcbba".toCharArray();
    }
    
    
    public static char[] getTestData2 ()
    {
        return "abccba".toCharArray();
    }
    
    
    public static char[] getTestData3 ()
    {
        return "abcabc".toCharArray();
    }
    
    
    public static char[] getTestData4 ()
    {
        return "abcba".toCharArray();
    }
}
