package oneit.test;

import oneit.access.ReadDatabase;
import oneit.model.Employee;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author OneIT
 */
public class Test2C {
    public static void main(String[] args) {
//      Use ReadDatabase.getEmployees () to get all employees
//      Print out those employees who are managers

        List<Employee> employeeList = Arrays.asList(ReadDatabase.getEmployees());

        Map<Employee, List<Employee>> managersList = new HashMap<>();

        employeeList.forEach(employee -> {
            Employee manager = employee.getManager();
            if (manager != null) {
                if (managersList.containsKey(manager)) {
                    List<Employee> employees = managersList.get(manager);
                    employees.add(employee);
                    managersList.put(manager, employees);
                } else {
                    List<Employee> employees = new ArrayList<>();
                    employees.add(employee);
                    managersList.put(manager, employees);
                }
            }
        });

        managersList.forEach((manager, employees) -> System.out.println(manager.getFirstName()));

    }
}
