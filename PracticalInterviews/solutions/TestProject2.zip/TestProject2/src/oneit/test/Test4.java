package oneit.test;

import oneit.access.ReadRegister;
import oneit.model.Booking;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

/**
 * @author OneIT
 */
public class Test4 {
    public static void main(String[] args) {
//      We have to create an application for hotel booking. Hotel is having 3 number of rooms.
//      Write down a code for checkAvailability function to check if 'y' number of rooms are
//      available on so and so date for start time and end time.
//      If room is partially available then don't consider that as available.

//      Example. Room 1 is already booked for 6th Nov,2014 from 12PM to 6PM.Consider this as
//              available for 6PM to 9PM but consider unavailable if we check for 5PM to 9PM.

//      Use ReadRegister.readAllBookings() to fetch all current bookings.
        Calendar start = new GregorianCalendar(2014, 11, 6, 19, 0, 0);
        Calendar end = new GregorianCalendar(2014, 11, 6, 21, 0, 0);

        System.out.println(checkAvailability(1, start, end));
    }

    public static boolean checkAvailability(int noOfRooms, Calendar start, Calendar end) {
        List<Booking> bookingList = ReadRegister.readAllBookings();
        boolean available = false;
        for (Booking booking : bookingList) {
            if (booking.getRoomNo() == noOfRooms && start.getTime().getDate() == booking.getStart().getTime().getDate()) {
                Calendar bookingStart = booking.getStart();
                Calendar bookingEnd = booking.getEnd();
                if (start.after(bookingStart) && start.before(bookingEnd)) {
                    continue;
                } else {
                    if (end.after(bookingStart) && end.before(bookingEnd)) {
                        continue;
                    } else {
                        available = true;
                    }
                }
            }
        }
        return available;
    }
}
