package oneit.test;

import oneit.access.ReadDatabase;
import oneit.model.Employee;
import oneit.model.PayRecord;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author OneIT
 */
public class Test2E
{

    static Employee mainManager = new Employee();
    static List<Employee> employees = new ArrayList<>();
    static List<PayRecord> payRecordList = new ArrayList<>();

    public static void main (String[] args)
    {
//      Use ReadDatabase.getEmployees () to get all employees
//      Print out the organisation hierarchy, with each level indented 4 spaces e.g. + their salary and the salary of all subordinates 
//      e.g. 80 is the sum of Tom Jones + Mark Smith + Phil Jones + David Jones + Paul Phillips salary
        
//      Tom Jones               80
//          Mark Smith          40
//              Phil Jones      10
//              David Jones     10
//          Paul Phillips       15
//      Another Manager
//          Subordinate
//          Subordinate 2

        employees.addAll(Arrays.asList(ReadDatabase.getEmployees()));
        payRecordList.addAll(ReadDatabase.getPayrollRecords());

        buildManagerTree(mainManager);
        printTree(mainManager, 0);
    }

    private static List<Employee> getEmployeesByManager(Employee manager) {
        List<Employee> employeeList = new ArrayList<>();
        for (Employee employee : employees) {
            if (employee.getManager() == null && manager.getFirstName() == null) {
                employeeList.add(employee);
                continue;
            }
            if (employee.getManager() != null && employee.getManager().equals(manager)) {
                employeeList.add(employee);
            }
        }
        return employeeList;
    }

    private static void buildManagerTree(Employee mainManager) {
        List<Employee> employeeList = getEmployeesByManager(mainManager);
        mainManager.setSubEmployeeList(employeeList);
        double totalSalary = 0;
        if (employeeList.isEmpty()) {
            return;
        }
        for (Employee employee : employeeList) {
            double employeeSalary = findSalaryByEmployee(employee);
            employee.setTotalSalaryOfSubordinates(employeeSalary);
            buildManagerTree(employee);
            totalSalary = totalSalary + employee.getTotalSalaryOfSubordinates();
        }
        totalSalary = totalSalary + findSalaryByEmployee(mainManager);
        mainManager.setTotalSalaryOfSubordinates(totalSalary);
    }

    private static void printTree(Employee mainManager, int level) {
        for (int i = 0; i < level; i++) {
            System.out.print("\t");
        }
        System.out.println(mainManager.getFirstName() != null ? mainManager.getFirstName() + " " + mainManager.getLastName() + " - " + mainManager.getTotalSalaryOfSubordinates() : "");

        List<Employee> employeeList = mainManager.getSubEmployeeList();

        for (Employee employee : employeeList) {
            printTree(employee, level + 1);
        }
    }

    private static double findSalaryByEmployee(Employee employee) {
        double totalSalary = 0;
        for (PayRecord payRecord : payRecordList) {
            if (payRecord.getEmployee().equals(employee)) {
                totalSalary = totalSalary + payRecord.getSalary();
            }
        }
        return totalSalary;
    }
}
