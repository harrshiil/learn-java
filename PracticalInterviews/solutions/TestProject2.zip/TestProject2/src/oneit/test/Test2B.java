package oneit.test;

import oneit.access.ReadDatabase;
import oneit.model.Employee;
import oneit.model.PayRecord;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * @author OneIT
 */
public class Test2B {
    public static void main(String[] args) {
//      Take output of Test4 to print all employees and their salary.
//      It should print records in sorted order of Employee Last Name, Frist Name, and City.

//      Example Output::
//      David Barton Perth 200.00
//      Harsh Shah Navarsi  600.00

        Map<Employee, Double> employeeSalaryRecords = new HashMap<>();

        List<PayRecord> payRecords = ReadDatabase.getPayrollRecords();
        payRecords.forEach(payRecord -> {
            Employee employee = payRecord.getEmployee();
            if (employeeSalaryRecords.containsKey(payRecord.getEmployee())) {
                Double updatedSalary = employeeSalaryRecords.get(employee) + payRecord.getSalary();
                employeeSalaryRecords.put(employee, updatedSalary);
            } else {
                employeeSalaryRecords.put(employee, payRecord.getSalary());
            }
        });

        employeeSalaryRecords.forEach((employee, salary) -> System.out.println(employee.getFirstName() + " " + employee.getLastName() + "\t" + salary));

        TreeMap<Employee, Double> sortedMap = new TreeMap<>();
        sortedMap.putAll(employeeSalaryRecords);

        System.out.println("\n\n");

        sortedMap.forEach((employee, salary) -> System.out.println(employee.getFirstName() + " " + employee.getLastName() + " " + employee.getCity() + "\t" + salary));
    }
}
