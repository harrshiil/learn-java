package oneit.test;

import oneit.access.ReadDatabase;
import oneit.model.Employee;
import oneit.model.PayRecord;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @author OneIT
 */
public class Test2A {
    public static void main(String[] args) {
//      Use ReadDatabase.getPayRecords() to get all salary records.
//      It will have Employee wise salary. 
//      Print out the total salary earned by each employee

        Map<Employee, Double> employeeSalaryRecords = new HashMap<>();

        List<PayRecord> payRecords = ReadDatabase.getPayrollRecords();
        payRecords.forEach(payRecord -> {
            Employee employee = payRecord.getEmployee();
            if (employeeSalaryRecords.containsKey(payRecord.getEmployee())) {
                Double updatedSalary = employeeSalaryRecords.get(employee) + payRecord.getSalary();
                employeeSalaryRecords.put(employee, updatedSalary);
            } else {
                employeeSalaryRecords.put(employee, payRecord.getSalary());
            }
        });

        employeeSalaryRecords.forEach((employee, salary) -> System.out.println(employee.getFirstName() + " " + employee.getLastName() + "\t" + salary));
    }
}
