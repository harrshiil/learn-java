/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package oneit.access;

import java.util.*;
import oneit.model.*;

/**
 *
 * @author OneIT
 */
public class ReadDatabase
{
    private static final Employee   HELEN           = new Employee("Helen", "Plange", "Perth", null);
    private static final Employee   DAVID_B         = new Employee("David", "Barton", "Perth", null);
    private static final Employee   YATI            = new Employee("Yati", "Hong", "Perth", DAVID_B);
    private static final Employee   HARSH           = new Employee("Harsh", "Shah", "Navsari", YATI);
    private static final Employee   PANKAJ          = new Employee("Pankaj", "Vaghasiya", "Surat", YATI);
    private static final Employee   DAVID_SMITH_M   = new Employee("David", "Smith", "Melbourne", HELEN);
    private static final Employee   DAVID_SMITH_A   = new Employee("David", "Smith", "Adelaide", HELEN);
    
    
    public static Employee[] getEmployees ()
    {
        return new Employee[] { HELEN, DAVID_B, DAVID_SMITH_A, DAVID_SMITH_M, HARSH, YATI, PANKAJ };
    }
    
    
    public static List<PayRecord> getPayrollRecords()
    {
        List<PayRecord> result = new ArrayList<>();
        
        
        result.add (new PayRecord(HARSH, 100.00));
        result.add (new PayRecord(DAVID_B, 200.00));
        result.add (new PayRecord(YATI, 300.00));
        result.add (new PayRecord(HARSH, 600.00));
        result.add (new PayRecord(PANKAJ, 600.00));
        result.add (new PayRecord(YATI, 100.00));
        result.add (new PayRecord(DAVID_SMITH_A, 75.00));
        result.add (new PayRecord(DAVID_SMITH_M, 150.00));
        result.add (new PayRecord(DAVID_SMITH_A, 90.00));
        result.add (new PayRecord(DAVID_SMITH_M, 250.00));
        result.add (new PayRecord(DAVID_B, 150.00));
        
        return result;
    }
    
}
